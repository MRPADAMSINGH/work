// Import the express module
var express = require('express');

// Import the cookie-parser middleware
var cookieParser = require('cookie-parser');

// Import the express-session middleware
var session = require('express-session');

// Create an Express application
var app = express();

// Define the PORT variable for the server to listen on
var PORT = 3000;

// Use the cookie-parser middleware in the Express app
app.use(cookieParser());

// Use the express-session middleware in the Express app with a secret key
app.use(session({ secret: "Shh, its a secret!" }));

// Define a route for the root path '/'
app.get('/', function (req, res) {
   // Check if the session variable 'page_views' exists
   if (req.session.page_views) {
      // If it exists, increment the 'page_views' variable in the session
      req.session.page_views++;
      // Respond with the number of times the user has visited the page
      res.send("You visited this page " + req.session.page_views + " times");
   } else {
      // If the 'page_views' variable doesn't exist, initialize it to 1 in the session
      req.session.page_views = 1;
      // Respond with a welcome message for the first-time visitor
      res.send("Welcome to this page for the first time!");
   }
});


// Define a route for '/logout' to destroy the session
app.get('/logout', function(req, res) {
   req.session.destroy(function(err) {
     if (err) {
       console.error(err);
       res.send('Error destroying session');
     } else {
       res.send('Session deleted successfully');
     }
   });
});

// Start the Express server and listen on the specified port
app.listen(PORT, () => {
   console.log(`Server is running on http://localhost:${PORT}`);
});
