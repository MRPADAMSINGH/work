// import the express module
var express=require('express');

//import the coockie-parser middeleware 
var coockieParser=require('cookie-parser');

//import the express session middleware 
var session=require('express-session');

// create an express application 
var app=express();

// dafine a port
var PORT=3000;

//use the cookie-parser
app.use(coockieParser());

// use the middleware as secreate key
app.use(session({secret:"shh, its a secret!"}));

//Dafine a route
app.get('/',function(req,res){
        //check session variable 
    if(req.session.page views()){
        req.session.page_views++;
        res.send("Your visited this page" +req.session.page_views+)
    }
})

