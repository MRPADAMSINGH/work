const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 4000;

// Middleware to parse JSON bodies
app.use(bodyParser.json());

// Define a POST route to handle JSON data
app.post('/', (req, res) => {
    const data = req.body;
    console.log(data); // Log the received data
    res.json({ message: 'Data received successfully!', data: data });
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
