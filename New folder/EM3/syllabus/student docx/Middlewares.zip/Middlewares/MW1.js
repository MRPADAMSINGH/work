const express = require('express');
const app = express()

function userMiddleware(req,res,next){
    let username = req.headers.username;
    let password = req.headers.password;
    if(username ==="Prateek" && password==="pass"){
      next();
      }else{
        res.status(401).json({
            "msg":"not authorized"
        })
      }
}
function ageMiddleware(req,res,next){
    let age = req.query.age;
    if(age<19){
        res.json({
            "msg":"Doctor only checks adults"
        })
    }else{
        req.age= age;
        next();
    }
}

app.get('/checkup',userMiddleware,(req,res)=>{

    res.send("your are healthy")

});
app.get('/checkupAge',userMiddleware,ageMiddleware,(req,res)=>{

    res.send("You are healthy");

});



app.listen(3000,()=>{
    console.log("server is running on http://localhost:3000")
})