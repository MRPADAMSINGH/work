const express = require('express');
const app = express();
let requests=0;
function countReqMiddleware(req,res,next){
   requests++
   console.log(requests)
    next()
}

app.use(countReqMiddleware);

app.get('/',(req,res)=>{
    res.send('hi')
})

app.listen(4000,()=>{
    console.log('app is running on http://localhost:4000')
})