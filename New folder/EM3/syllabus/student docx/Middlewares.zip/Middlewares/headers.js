const express = require('express');
const app = express()

app.get('/',(req,res)=>{
    let age = req.query.age;
    let username = req.headers.username;
    let password = req.headers.password;
    console.log(username);
    console.log(password);
    
  if(username ==="Prateek" && password==="pass"){
    res.json({
        "msg":"Your health is fine"
    })
  }else{
    res.json({
        "msg":"Your age is "+age
    })
  }
});

app.listen(3000,()=>{
    console.log("server is running on http://localhost:3000")
})